var ItemData = [
   {
      name: "Wireless Headphones",
      price: 89,
      color: "Black",
      style: "Electronics",
      year: 2023,
      img: "images/headphones.png",
      info: "Noise-cancelling with 20hr battery life",
      hasSizes: false
   },
   {
      name: "Air Fryer",
      price: 149,
      color: "Black",
      style: "Kitchen",
      year: 2022,
      img: "images/airfrayer.png",
      info: "Healthier frying with no need for oil",
      hasSizes: false
   },
   {
      name: "Desk Lamp",
      price: 39,
      color: "Matte Black",
      style: "Electronics",
      year: 2021,
      img: "images/lamp.png",
      info: "Touch-control lamp with adjustable brightness",
      hasSizes: true
   },
   {
      name: "Cotton T-Shirt",
      price: 25,
      color: "Green",
      style: "Clothes",
      year: null,
      img: "images/tshirt.png",
      info: "Soft breathable cotton for all-day comfort. Available in multiple fits",
      hasSizes: true
   },
   {
      name: "Toy Robot",
      price: 19,
      color: "Silver",
      style: "Electronics",
      year: null,
      img: "images/toyrobot.png",
      info: "Fun collectible wind-up toy for kids",
      hasSizes: false
   },
   {
      name: "Bluetooth Speaker",
      price: 45,
      color: "Blue",
      style: "Electronics",
      year: 2023,
      img: "images/speaker.png",
      info: "Compact speaker with deep bass and 10hr battery",
      hasSizes: true
   }
];

const SHIPPING_FLAT_RATE = 5.95; // Flat shipping rate for all orders
// const TAX_RATE = 0.07; // 7% tax on subtotal maybe will add that (Aus GST is usually included in price)

/* ---------- Size pricing rules ---------- */
/* ---------- Size pricing rules (with Clothes excluded) ---------- */
const SIZE_MULTIPLIER = {
   Small: 1.00,   // base price
   Medium: 1.08,  // +8%
   Large: 1.18    // +18%
};

const SIZE_MIN_DELTA = { Medium: 2.00, Large: 4.00 }; // at least +$2 / +$4

// styles that should NOT be affected by size pricing
const SIZE_EXCLUDE_STYLES = new Set(["clothes"]); // case-insensitive

function priceWithSize(product, size) {
   const base = Number(product.price) || 0;

   // Skip adjustments for excluded categories (e.g., Clothes)
   if (SIZE_EXCLUDE_STYLES.has(String(product.style).toLowerCase())) {
      return Math.round(base * 100) / 100;
   }

   const pctPrice = base * (SIZE_MULTIPLIER[size] ?? 1);
   const floor = base + (SIZE_MIN_DELTA[size] ?? 0);
   const final = Math.max(pctPrice, floor);
   return Math.round(final * 100) / 100;
}

/* --------------------------------------- */

var selectedItem = [];
var gallery = document.querySelector("#gallery");

function displayProducts(products) {
   if (!gallery) return;

   gallery.innerHTML = "";

   products.forEach(product => {
      var nicePrice = product.price.toLocaleString('en-AU', { style: 'currency', currency: 'AUD' });
      var div = document.createElement("div");
      div.className = "item";
      div.ref = product;

      let details = [product.color, product.style].filter(Boolean).join(" , ");

      div.innerHTML = `
      <h4>${product.name}</h4>
      <h6>${details}</h6>
      <img src="${product.img}" alt="${product.name}">
      <p>${nicePrice}</p>
    `;

      gallery.appendChild(div);

      div.addEventListener("click", function () {
         localStorage.setItem("clickedProduct", JSON.stringify(product));
         window.location.href = "shoepage.html";
      });
   });
}

window.filter = function (styles) {
   let filteredProducts;

   if (styles.value === "all") {
      filteredProducts = ItemData;
   } else {
      filteredProducts = ItemData.filter(product => product.style.toLowerCase() === styles.value.toLowerCase());
   }

   displayProducts(filteredProducts);
}

function filterItem(query) {
   const filtered = ItemData.filter(product =>
      product.name.toLowerCase().includes(query.toLowerCase())
   );
   if (filtered.length > 0) {
      displayProducts(filtered);
   } else {
      gallery.innerHTML = "<h1> No items found </h1>"
      console.log("no items found")
   }
}

displayProducts(ItemData);

const searchBarInput = document.querySelector("#searchbar input");
searchBarInput.addEventListener("input", function () {
   const query = searchBarInput.value;
   filterItem(query);
});

var savedShoppingList = JSON.parse(localStorage.getItem("shoppingList")) || [];
var faveList = JSON.parse(localStorage.getItem("faveList")) || [];

import { addToCart, animateShoes } from './animation.js';
animateShoes();


//dark mode toggle
document.addEventListener('DOMContentLoaded', () => {
   const themeToggleButton = document.getElementById("theme-toggle");
   const icon = themeToggleButton.querySelector("i");

   // Load saved theme
   if (localStorage.getItem("theme") === "dark") {
      document.body.classList.add("dark-mode");
      icon.classList.replace("fa-moon", "fa-sun");
      icon.classList.add("sun-grad");
   }

   // Toggle theme
   themeToggleButton.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");

      if (document.body.classList.contains("dark-mode")) {
         localStorage.setItem("theme", "dark");
         icon.classList.replace("fa-moon", "fa-sun");
         icon.classList.add("sun-grad");
      } else {
         localStorage.setItem("theme", "light");
         icon.classList.replace("fa-sun", "fa-moon");
         icon.classList.remove("sun-grad");
      }
   });
});





//===========================================================================
//!====================== SECOND PAGE =======================================
//===========================================================================

window.onload = function () {
   const pathname = window.location.pathname;

   if (pathname.includes("shoepage.html")) {
      secondpage();
   } else if (pathname.includes("cart.html")) {
      thirdpage();
   }
};

export function secondpage() {
   function updateLocalStorage() {
      localStorage.setItem("shoppingList", JSON.stringify(shoppingList));
      localStorage.setItem("faveList", JSON.stringify(favelist));
   }

   var clickedProduct = JSON.parse(localStorage.getItem('clickedProduct'));

   var productSizes = ["Small", "Medium", "Large"];
   var shoppingList = JSON.parse(localStorage.getItem("shoppingList")) || [];
   var favelist = JSON.parse(localStorage.getItem("faveList")) || [];

   if (clickedProduct) {
      var shoebox = document.querySelector('#shoebox');
      if (!shoebox) return;

      // Show Small (base) price by default
      var basePrice = priceWithSize(clickedProduct, "Small");
      var nicePrice = basePrice.toLocaleString('en-AU', { style: 'currency', currency: 'AUD' });

      var imgbox = document.createElement('div');
      imgbox.classList.add('image');

      let imgStyle = "";

      if (
         clickedProduct.img.includes("toyrobot.png") ||
         clickedProduct.img.includes("tshirt.png")
      ) {
         imgStyle = 'style="width: 90%; max-width: 300px;"'; // adjust as needed
      }
      imgbox.innerHTML = `<img src="${clickedProduct.img}" alt="${clickedProduct.name}" ${imgStyle}>`;

      shoebox.appendChild(imgbox);

      document.querySelector('.information').innerHTML +=
         `<h1>${clickedProduct.name}</h1>
       <h4>${clickedProduct.style}</h4>
       <h3 id="price">${nicePrice}</h3>`;
   }

   const information = document.querySelector('.information');

   // Only show sizes if the product has sizes
   if (clickedProduct.hasSizes) {
      var selectSizeHeading = document.createElement('h2');
      selectSizeHeading.innerHTML = '<h1>Select size</h1>';
      information.appendChild(selectSizeHeading);

      var sizesContainer = document.createElement('div');
      sizesContainer.classList.add('sizes');

      productSizes.forEach(sizeNumber => {
         var sizeDiv = document.createElement('div');
         sizeDiv.classList.add('size');
         sizeDiv.innerHTML = `<h2>${sizeNumber}</h2>`;
         sizesContainer.appendChild(sizeDiv);
         information.appendChild(sizesContainer);

         sizeDiv.addEventListener('click', function () {
            document.querySelectorAll('.size').forEach(s => s.classList.remove('selected'));
            sizeDiv.classList.add('selected');
            clickedProduct.selectedSize = sizeNumber;

            // Update displayed price when size changes
            const newPrice = priceWithSize(clickedProduct, sizeNumber);
            const priceEl = document.getElementById('price');
            if (priceEl) {
               priceEl.textContent = newPrice.toLocaleString('en-AU', { style: 'currency', currency: 'AUD' });
            }
         });
      });
   }

   const cart = document.createElement('div');
   const fave = document.createElement('div');

   cart.classList.add('add-to-cart');
   fave.classList.add('favorite');

   cart.innerHTML = `<h2>Add to cart &nbsp; <i class="fa-solid fa-cart-shopping"></i></h2>`;
   fave.innerHTML = `<h2>Favorite &nbsp; <i class="fa-regular fa-heart"></i></h2>`;

   information.appendChild(cart);
   information.appendChild(fave);

   document.querySelector(`#backstory`).innerHTML = `<h3>${clickedProduct.info}</h3>`;

   cart.addEventListener('click', function () {
      if (clickedProduct.hasSizes && !clickedProduct.selectedSize) {
         alert("Please select a size before adding to the cart");
         return;
      }

      // Determine size-adjusted unit price
      const chosenSize = clickedProduct.hasSizes ? clickedProduct.selectedSize : "Small";
      const unitPrice = clickedProduct.hasSizes
         ? priceWithSize(clickedProduct, chosenSize)
         : clickedProduct.price;

      const matchBy = clickedProduct.hasSizes
         ? item => item.name === clickedProduct.name && item.selectedSize === clickedProduct.selectedSize
         : item => item.name === clickedProduct.name;

      var existingItem = shoppingList.find(matchBy);

      if (existingItem) {
         // keep existing per-item price; just bump quantity
         existingItem.quantityDisplay = (existingItem.quantityDisplay || 1) + 1;
         existingItem.quantity = (existingItem.quantity || 1) + 1;
         addToCart();
      } else {
         // store the chosen size AND the size-adjusted price
         const itemToAdd = { ...clickedProduct };
         itemToAdd.quantityDisplay = 1;
         itemToAdd.quantity = 1;
         itemToAdd.price = unitPrice; // <--- size-adjusted price saved
         if (clickedProduct.hasSizes) itemToAdd.selectedSize = chosenSize;

         shoppingList.push(itemToAdd);
         addToCart();
      }

      localStorage.setItem("shoppingList", JSON.stringify(shoppingList));
   });

   fave.addEventListener('click', function () {
      const matchBy = clickedProduct.hasSizes
         ? item => item.name === clickedProduct.name && item.selectedSize === clickedProduct.selectedSize
         : item => item.name === clickedProduct.name;

      const itemIndex = favelist.findIndex(matchBy);

      if (itemIndex === -1) {
         favelist.push({ ...clickedProduct });
         fave.innerHTML = `<h2> Favourite &nbsp; <i class="fa-solid fa-heart"></i></h2>`;
         fave.classList.add('added-to-favorites');
      } else {
         favelist.splice(itemIndex, 1);
         fave.innerHTML = `<h2> Add to Favorites &nbsp; <i class="fa-regular fa-heart"></i></h2>`;
         fave.classList.remove('added-to-favorites');
      }
      updateLocalStorage();
   });
}


//===========================================================================
//!======================THIRD PAGE==========================================
//===========================================================================

function thirdpage() {
   var shoppingList = JSON.parse(localStorage.getItem("shoppingList")) || [];
   var items = document.querySelector(".items");
   var priceDiv = document.querySelector(".total");

   if (!items || !priceDiv) return;

   items.innerHTML = "";
   priceDiv.innerHTML = "";

   if (shoppingList.length === 0) {
      var emptyMessage = document.createElement("p");
      emptyMessage.classList.add("empty");
      emptyMessage.textContent = "Your shopping cart is empty.";
      items.appendChild(emptyMessage);
      const vline = document.querySelector(".vertical-line");
      if (vline) vline.style.backgroundColor = "transparent";
      return;
   }

   let subtotal = 0;

   shoppingList.forEach((item, index) => {
      var thirdimgbox = document.createElement('div');
      thirdimgbox.classList.add('thirdimgbox');

      var imgbox = document.createElement('div');
      imgbox.classList.add('imgbox');
      imgbox.innerHTML = `<img src="${item.img}" alt="${item.name}">`;
      thirdimgbox.appendChild(imgbox);

      var controlBox = document.createElement('div');
      controlBox.classList.add('controlBox');

      var trasBtn = document.createElement('div');
      trasBtn.classList.add('trashBtn');
      trasBtn.innerHTML = `<i class="fa-solid fa-trash"></i>`;
      controlBox.appendChild(trasBtn);

      var minusbtn = document.createElement('button');
      minusbtn.classList.add('minusbtn');
      minusbtn.innerHTML = '<i class="fa-solid fa-minus"></i>';
      controlBox.appendChild(minusbtn);

      var quantityDisplay = document.createElement('span');
      quantityDisplay.classList.add('quantity');
      quantityDisplay.textContent = item.quantityDisplay;
      controlBox.appendChild(quantityDisplay);

      var plusButton = document.createElement('button');
      plusButton.classList.add('plusBtn');
      plusButton.innerHTML = '<i class="fa-solid fa-plus"></i>';
      controlBox.appendChild(plusButton);

      imgbox.appendChild(controlBox);

      var iteminfo = document.createElement('div');
      var name = document.createElement("h2");
      name.textContent = item.name + (item.selectedSize ? ` (${item.selectedSize})` : "");
      iteminfo.appendChild(name);

      var style = document.createElement("p");
      style.textContent = `Style: ${item.style}`;
      iteminfo.appendChild(style);

      if (item.selectedSize) {
         var size = document.createElement("p");
         size.textContent = `Size: ${item.selectedSize}`;
         iteminfo.appendChild(size);
      }

      var price = document.createElement("p");
      price.classList.add('price');
      price.textContent = `Price: ${Number(item.price).toLocaleString('en-AU', { style: 'currency', currency: 'AUD' })}`;
      iteminfo.appendChild(price);

      thirdimgbox.appendChild(iteminfo);
      items.appendChild(thirdimgbox);

      var hr = document.createElement('hr');
      hr.classList.add('hr');
      items.appendChild(hr);

      // item.price is already the size-adjusted price we saved in secondpage()
      subtotal += (Number(item.price) || 0) * (item.quantity || 1);

      trasBtn.addEventListener('click', function () {
         shoppingList.splice(index, 1);
         localStorage.setItem("shoppingList", JSON.stringify(shoppingList));
         thirdpage();
      });

      plusButton.addEventListener('click', function () {
         item.quantityDisplay = (item.quantity || 1) + 1;
         item.quantity = (item.quantity || 1) + 1;
         quantityDisplay.textContent = item.quantity;
         localStorage.setItem("shoppingList", JSON.stringify(shoppingList));
         thirdpage();
      });

      minusbtn.addEventListener('click', function () {
         if (item.quantity > 1) {
            item.quantityDisplay -= 1;
            item.quantity -= 1;
            quantityDisplay.textContent = item.quantity;
            localStorage.setItem("shoppingList", JSON.stringify(shoppingList));
            thirdpage();
         }
      });
   });

   const shipping = shoppingList.length ? SHIPPING_FLAT_RATE : 0;
   const total = subtotal + shipping;

   var summaryDiv = document.createElement("div");
   summaryDiv.classList.add("summary-section");

   var summaryTitle = document.createElement("h3");
   summaryTitle.textContent = "Summary";
   summaryDiv.appendChild(summaryTitle);

   var subtotalRow = document.createElement("div");
   subtotalRow.classList.add("summary-row", "no-devider");
   subtotalRow.innerHTML = `<span>Subtotal</span><span class="subtotal">${subtotal.toLocaleString('en-AU', { style: 'currency', currency: 'AUD' })}</span>`;
   summaryDiv.appendChild(subtotalRow);

   var shippingRow = document.createElement("div");
   shippingRow.classList.add("summary-row", 'shipping-row');
   shippingRow.innerHTML = `<span>Shipping</span>
    <span class="shipping">${shipping.toLocaleString('en-AU', { style: 'currency', currency: 'AUD' })}</span>`;
   summaryDiv.appendChild(shippingRow);

   var totalRow = document.createElement("div");
   totalRow.classList.add("summary-row");
   totalRow.innerHTML = `<span>Total</span>
    <span class="grand-total">${total.toLocaleString('en-AU', { style: 'currency', currency: 'AUD' })}</span>`;
   summaryDiv.appendChild(totalRow);

   var guestCheckoutButton = document.createElement("button");
   guestCheckoutButton.classList.add("checkout-btn");
   guestCheckoutButton.id = "pay-btn";
   guestCheckoutButton.textContent = " Checkout";
   summaryDiv.appendChild(guestCheckoutButton);

   var payError = document.createElement("p");
   payError.id = "pay-error";
   summaryDiv.appendChild(payError);

   priceDiv.appendChild(summaryDiv);

   wireCheckoutModal();
}

//! Ensure the checkout modal exists and set up its functionality
function ensureCheckoutModal() {
   if (document.getElementById('checkout-overlay')) return;

   const overlay = document.createElement('div');
   overlay.id = 'checkout-overlay';
   overlay.className = 'modal-overlay';
   overlay.innerHTML = `
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
    <header>
      <h3 id="checkout-title">Shipping Details</h3>
      <button class="close-btn" aria-label="Close">✕</button>
    </header>

    <form id="shipping-form" class="form-grid" novalidate>
      <label class="full">Full name
        <input id="fullName" required />
      </label>

      <label>Phone
        <input id="phone" type="tel" required />
      </label>

      <label>Postcode
        <input id="postcode" required />
      </label>

      <!-- Dropdowns -->
      <label class="full">Country
        <select id="country" required>
          <option value="">Select country</option>
        </select>
      </label>

      <label>State
        <select id="state" required disabled>
          <option value="">Select state</option>
        </select>
      </label>

      <label>Suburb
        <select id="suburb" required disabled>
          <option value="">Select suburb</option>
        </select>
      </label>

      <label class="full">Address line 1
        <input id="line1" required />
      </label>

      <label class="full">Address line 2
        <input id="line2" />
      </label>

      <p id="modal-error"></p>
    </form>

    <footer>
      <button type="button" class="btn-secondary" id="modal-cancel">Cancel</button>
      <button type="button" class="btn-primary" id="modal-continue" disabled>Continue</button>
    </footer>
  </div>
`;
   document.body.appendChild(overlay);

   // Cascading data (sample)
   const REGIONS = {
      Australia: {
         "New South Wales": ["liverpool", "Parramatta", "central", "New castle"],
         "Victoria": ["Melbourne", "Geelong", "Ballarat"],
         "Queensland": ["Brisbane", "Gold Coast", "Cairns"],
         "Western Australia": ["Perth", "Fremantle"],
         "South Australia": ["Adelaide"],
         "Tasmania": ["Hobart"],
         "Australian Capital Territory": ["Canberra"],
         "Northern Territory": ["Darwin"]
      }
   };

   const countrySel = overlay.querySelector('#country');
   const stateSel = overlay.querySelector('#state');
   const suburbSel = overlay.querySelector('#suburb');

   function resetSelect(sel, placeholder, enabled = false) {
      sel.innerHTML = `<option value="">${placeholder}</option>`;
      sel.disabled = !enabled;
   }
   function fillSelect(sel, list) {
      const frag = document.createDocumentFragment();
      list.forEach(v => {
         const opt = document.createElement('option');
         opt.value = v; opt.textContent = v;
         frag.appendChild(opt);
      });
      sel.appendChild(frag);
   }

   // Countries
   resetSelect(countrySel, 'Select country', true);
   fillSelect(countrySel, Object.keys(REGIONS));
   countrySel.value = 'Australia'; // default if you want

   countrySel.addEventListener('change', () => {
      const c = countrySel.value;
      resetSelect(stateSel, 'Select state');
      resetSelect(suburbSel, 'Select suburb');
      if (c && REGIONS[c]) {
         fillSelect(stateSel, Object.keys(REGIONS[c]));
         stateSel.disabled = false;
      }
   });

   stateSel.addEventListener('change', () => {
      const c = countrySel.value;
      const s = stateSel.value;
      resetSelect(suburbSel, 'Select suburb');
      if (c && s && REGIONS[c]?.[s]) {
         fillSelect(suburbSel, REGIONS[c][s]);
         suburbSel.disabled = false;
      }
   });

   // kick things off
   countrySel.dispatchEvent(new Event('change'));

   // Close handlers (X, Cancel, outside click, Esc)
   const close = () => { overlay.classList.remove('open'); document.body.style.overflow = ''; };
   overlay.querySelector('.close-btn').addEventListener('click', close);
   overlay.querySelector('#modal-cancel').addEventListener('click', close);
   overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
   document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && overlay.classList.contains('open')) close(); });

   // Simple validation to enable Continue
   const errEl = overlay.querySelector('#modal-error');
   const continueBtn = overlay.querySelector('#modal-continue');
   const form = overlay.querySelector('#shipping-form');

   function readShip() {
      const get = id => (overlay.querySelector('#' + id)?.value || '').trim();
      return {
         fullName: get('fullName'),
         phone: get('phone'),
         line1: get('line1'),
         postcode: get('postcode'),
         country: get('country'),
         state: get('state'),
         suburb: get('suburb')
      };
   }

   function validateShip() {
      const s = readShip();
      const required = ['fullName', 'phone', 'line1', 'postcode', 'country', 'state', 'suburb'];
      const ok = required.every(k => !!s[k]);
      overlay.querySelector('#modal-continue').disabled = !ok;
      overlay.querySelector('#modal-error').textContent = ok ? '' : 'Please fill in all required fields.';
      return ok;
   }

   form.addEventListener('input', validateShip);
   validateShip();

   // Continue (next step: show payment or place order)
   continueBtn.addEventListener('click', () => {
      if (!validateShip()) return;

      window.__mockShipping = readShip();

      close();

      console.log('Shipping captured:', window.__mockShipping);

      alert("Thank you for your order! your order is being processed. \n\n" +
         "Your order will be shipped soon. Thank you for shopping with us!"
      );
   });
}

// Open the modal when clicking "Checkout"
function wireCheckoutModal() {
   const btn = document.getElementById('pay-btn');
   if (!btn) return;
   btn.addEventListener('click', (e) => {
      e.preventDefault();
      ensureCheckoutModal();
      const overlay = document.getElementById('checkout-overlay');
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden'; // prevent background scroll
   });
}
