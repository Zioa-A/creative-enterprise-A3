//i told u i wouldnt be able to wait untill next assessment to 
//do some animations so here is my attempt 



export function animateShoes() {
    // Immediately animate the shoes on page load
    if (!document.querySelector('.shoe-0')) return;

    gsap.to(".shoe-0", {
        // x: 150,
        duration: 2,
        repeat: -1,
        yoyo: true,
        ease: "power1.inOut"
    });

    gsap.to(".shoe-1", {
        y: 5,
        duration: 2,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
        filter: "drop-shadow(0px 0px 70px rgba(0, 255, 0, 0.9))",
        onUpdate: function () {
            gsap.to(".shoe-1", {
                duration: 1,
                scale: 1.05,
                ease: "power1.inOut"
            });
        }
    });

    gsap.to(".shoe-2", {
        filter: "drop-shadow(0px 0px 20px rgba(0, 255, 255, 0.8))",
        duration: 1.5,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut"
    });

    gsap.to(".shoe-2", {
        y: -10,
        duration: 2,
        repeat: -1,
        yoyo: true,
        ease: "power1.inOut"
    });
}


export function addToCart() {
    gsap.to(".image", {
        x: 0,
        y: 100,
        scale: 0.1,
        duration: 2,
        ease: "bounce.in",
        onComplete: () => {

            //here what i orinally wanted to do is the shoegose all the way to the 
            //shopping cart symbole at the right corner and disapear and then the shoe
            //would appear back in its its place and it didnt work 
            //then tried to make it so the shoe would go small and then a shopping 
            //cart appears becomes big and then it would change back into the shoe 
            //also didnt work so what i did is made the shopping cart 
            //symbole appear and becuse i dont know how to change it back to that 
            //shoe i mad it so that you can click on that shoping cart and it wold take you 
            //to the cart page

            //i know that was a big coment and i hope it wasnt useless 


            document.querySelector(".image").innerHTML = `<a href="cart.html" class="cart-link">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </a>`
            gsap.to(`.image`, {
                y: 10,
                scale: 15,
                ease: `sine.out`
            })
        }
    });



}

    gsap.registerPlugin(ScrollTrigger);

window.addEventListener("DOMContentLoaded", () => {
  gsap.registerPlugin(ScrollTrigger);

  let lastScroll = 0;
  const navbar = document.getElementById("navbar");

  ScrollTrigger.create({
    start: 0,
    end: document.body.scrollHeight,
    onUpdate: (self) => {
      const currentScroll = self.scroll();

      if (currentScroll > lastScroll) {
        // scrolling down – hide navbar
        gsap.to(navbar, { y: -100, duration: 0.3, ease: "power2.out" });
      } else {
        // scrolling up – show navbar
        gsap.to(navbar, { y: 0, duration: 0.3, ease: "power2.out" });
      }

      lastScroll = currentScroll;
    }
  });
});

