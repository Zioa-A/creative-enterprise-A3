var images = [
    {
        background: "images/blase-back.png",
        shoe: "images/mixer.png"
    },
    {
        background: "images/noe-back.png",
        shoe: "images/toaster.png"
    },
    {
        background: "images/meta-back.png",
        shoe: "images/pc.png"
    }
];

function generateCarousel(images) {
    const carouselContainer = document.getElementById('carousel-container');

    const carousel = document.createElement('div');
    carousel.classList.add('carousel');
    
    images.forEach((image,inddex) => {
        const slide = document.createElement('div');
        slide.classList.add('carousel-slide');

        const background = document.createElement('div');
        background.classList.add('carousel-background');
        background.style.backgroundImage = `url(${image.background})`;

        const shoe = document.createElement('img');
        shoe.src = image.shoe;
        shoe.alt = "Shoe Image";
        shoe.classList.add('carousel-shoe', `shoe-${inddex}`);

        slide.appendChild(background);
        slide.appendChild(shoe);
        carousel.appendChild(slide);
    });

    const prevButton = document.createElement('button');
    prevButton.classList.add('prev');
    prevButton.innerHTML = "&#10094;";
    prevButton.onclick = () => changeImage(-1);

    const nextButton = document.createElement('button');
    nextButton.classList.add('next');
    nextButton.innerHTML = "&#10095;";
    nextButton.onclick = () => changeImage(1);

    carouselContainer.appendChild(carousel);
    carouselContainer.appendChild(prevButton);
    carouselContainer.appendChild(nextButton);

    let currentIndex = 0;

    // Function to change image based on direction
    function changeImage(direction) {
        currentIndex += direction;

        if (currentIndex >= images.length) {
            currentIndex = 0;
        } else if (currentIndex < 0) {
            currentIndex = images.length - 1;
        }

        // Apply sliding transition effect
        carousel.style.transition = "transform 1s ease"; // Add transition for smooth sliding
        carousel.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    // Auto-slide functionality: move every 3 seconds
    
     setInterval(() => {
         changeImage(1); // Move to next image automatically
     }, 3000); 3000 //ms = 3 seconds
 }

// Call the function to generate the carousel with images
generateCarousel(images);
